#' @export

print.get_emotion <- function(x, ...) {

  cat("This emotion is used ", x$b, " times, and is present in ", x$c,
      "% of tweets.", sep = "")
}

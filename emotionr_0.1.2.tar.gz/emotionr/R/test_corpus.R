#' Emotionr Courage Test Corpus
#'
#' This is a data frame of test data to use with courage within emotionr.
#'
#' @format A data frame with 40 rows and 2 columns.
#' \describe{
#' \item{key}{Text key}
#' \item{text}{Text to use for testing in emotionr}
#'
#' }
#'
#' @author Jane Cronin
"test_corpus"

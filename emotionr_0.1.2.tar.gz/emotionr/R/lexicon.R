#' Emotionr Lexicon
#'
#' This is the lexicon used by emotionr, showing all the words present in the lexicon
#' and which emotions they relate to.
#'
#' @format A data frame with 2 rows and 3 columns.
#' \describe{
#' \item{word}{The key word which is associated with a specific emotion}
#' \item{emotion}{The emotions contained in the lexicon}
#' \item{value}{Whether or not the emotion is associated with the word; a value of
#' 1 shows that it is, a value of 0 that it is not.}
#' }
#'
#' @author Jane Cronin


lexicon <- data.frame(word = c("courage", "courageous"), emotion = c("courage", "courage"),
                         value = c(1, 1))

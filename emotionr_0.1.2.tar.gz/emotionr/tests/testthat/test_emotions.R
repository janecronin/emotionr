library(emotionr)
context("testing if emotions are present")

test_that("courage is present", {
  expect_equal(get_emotion(test_corpus$text, "courage")[[1]], 25
               )
}
)


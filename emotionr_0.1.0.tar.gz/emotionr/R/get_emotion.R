#' Get_emotion
#'
#' Calculate the sentiments present in a tweet corpus.
#'
#' This package expands on established lexicons to allow users to understand if
#' sentiments including courage (expand as add more sentiments to lexicon), are
#' present in a text corpus, scraped using rtweet or similar. Users can see
#' a tweet by tweet view, the number of times the sentiment is used and the percentage
#' of tweets in a dataset which use it.
#'
#' @author Jane Cronin
#'
#' @param x A selected column of text from a data frame of tweets.
#' @param y The specific emotion selected from the emotionr lexicon.
#'
#' @return A list with two elements
#' \describe{
#' \item{b}{The number of times the selected emotion is used}
#' \item{c}{The percentage of tweets which use this emotion}}
#'
#' @export

get_emotion <- function(x, y, z){

  sublex <- lexicon %>% filter(emotion == z)
  emotions <- get_sentiment(y, method = "custom", lexicon = sublex)
  summed_e <- sum(emotions, na.rm = TRUE)
  number_tweets <- nrow(x)
  emo_pres <-   emotions %>%
    as_tibble() %>%
    mutate(emo_present = if_else(value >= 1, 1, 0)) %>%
    summarise(s = sum(emo_present))
  percent_tweets <- as.numeric(emo_pres) / number_tweets * 100
  x <- x %>% mutate(sum_emotion = emotions)
  list_to_return <- list(b = summed_e, c = percent_tweets)
  attr(list_to_return, "class") <- "get_emotion"
  return(list_to_return)
  return(head(x))

}


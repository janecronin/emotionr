#' emotionr: expanded sentiment analysis
#'
#' The emotionr package provides functions for expanded sentiment analysis looking at
#' courage. Other emotions will be added at a later date.
#'
#' @section
#'
#' @docType package
#' @name emotionr
NULL

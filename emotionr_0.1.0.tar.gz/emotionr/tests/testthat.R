library(testthat)
library(emotionr)

test_check("emotionr")
